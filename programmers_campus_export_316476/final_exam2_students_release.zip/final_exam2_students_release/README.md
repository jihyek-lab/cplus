# 기말고사 2 학생 배포본

- 구성: 7문제
- 대상: 학생 실습용 starter code 배포본
- 포함 파일: 각 문제 폴더의 `README.md`, `main.cpp`
- 제외 파일: `solution.cpp`, 실행 파일, 기타 임시 파일

## 사용 방법

1. 원하는 문제 폴더로 이동합니다.
2. `README.md`를 먼저 읽고 문제 요구사항을 확인합니다.
3. `main.cpp`의 TODO를 채우면서 실습합니다.
4. 필요하면 아래처럼 컴파일해서 실행합니다.

```bash
g++ -std=c++17 main.cpp -o main
./main
```

## 문제 목록

- `01_matrix_operators_friend`
- `02_myqueue_inheritance`
- `03_loopadder_abstract_class`
- `04_graphic_editor_virtual`
- `05_template_functions`
- `06_map_grade_manager`
- `07_vector_circle_pointers`
